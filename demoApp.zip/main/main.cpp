/*
https://github.com/espressif/arduino-esp32/blob/master/docs/source/tutorials/preferences.rst

Deleting key-value Pairs
preferences.clear();
Deletes all the key-value pairs in the currently opened namespace.
The namespace still exists.
The namespace must be open in read-write mode for this to work.
preferences.remove("keyname");
Deletes the "keyname" and value associated with it from the currently opened namespace.
The namespace must be open in read-write mode for this to work.
Tip: use this to remove the "test key" to force a "factory reset" during the next reboot (see the Real World Example above).
If either of the above are used, the key-value pair will need to be recreated before using it again.
*/

/*
    espBasicOTA

    This sketch demonstrates how to use the AsyncEspOTA Library.  The main aims 
    of the library are to make 3 things simple for end users of IoT retail products:
      1) initial "Out of Box" connection to product,
      2) configuring wifi settings of the product and 
      3) installing firmware updates to the product as new features and bug fixes are released.
    
    It is also a starting point for IoT based projects which will include webpages served by 
    the esp32 and the AsyncEspOTA library adds Over the Aiur firmware updates from a gitHub 
    repository, custom URL and web client local file systems.  
    
    It uses an AsyncWebServer and WebSocketsServer to display webpages and show firmware update progresss 
    including error messages on the /firmware web pages if the update fails.

    The library uses some JSON files to select which firmwware poroject and which version you wish to load 
    into the esp32.

    The sketch is broken up into several files to keep various elements of the code spearated.  
    demo.h includes all the library references and Global variable declarations.
    demo_WebServer.ino includes the user webpages, event handlers and callback functions.
    demo_WiFi_Prefs.ino includes all the wifi initialisation functions, ssid and Password 
        settings which are saved from the web server and stored via the preferences library functions.

    If the library and supporting commands are added into multiple different projects, it is 
    possible to add them into the inderlying JSON apps list so that they may be uploded Over The Air    
    
    The circuit:
    * esp32
    * no additional compulsory harware 
    
    Created 22 Nov 2022
    By Romehein
    https://github.com/RomeHein/ESPInstaller

    Modified 25 February 2023  (converted to Arduino Library with progress bar feedback)
    By Lindsay McPhee

    https://github.com/linzmeister/AsyncEspOTA

*/

//#include "demo.h"


//Libraries **************************************************************************
#include <Arduino.h>
#include <WiFi.h>         // We're in IoT land, do as IoT does
//#include <esp_wps.h>    // wifi provisioning via WPS

#include <H4.h>
#include<H4AsyncWebServer.h>

#include<FS.h>
#include<SPIFFS.h>

#define HAL_FS SPIFFS
#define MY_BOARD "ESP32 Dev Board"
#define DEVICE "FULL_HOUSE"

#include <nvs_flash.h>        // uncomment to be able to erase all flash

// #in clude <WebSocketsServer.h>   // allows OTAUpdate progress bar to send increasing values to browser page.

#include <SPIFFS.h>
#define FORMAT_SPIFFS_IF_FAILED false;

#include <H4AsyncEspOTA.h>        //library under test !!!

const char *ssidPrefix = "AsyncEspOTA_";
const char *APpassword = "123456789";

//WiFiMulti wifiMulti;
long int savedTime;

const int wsPort = 1337;            // variableName must match library decalaration..        declared extern in library..  Port value may be different

                                    //VariableName must match library decalaration..         declared extern in library..
const char *appsURL= "https://raw.githubusercontent.com/linzmeister/AsyncEspOTA/main/DemoRepo/apps.json";

H4 h4(115200);
H4AsyncWebServer webServer(80);       // variableName must match library object declaration..  declared extern in library..  Port value may be different

// WebSocketsServer webSocket(wsPort); // variableName must match library object declaration..  declared extern in library..

bool allowAppsURL = true;
bool allowCustomPaths = false;
bool allowLocal = false;

//AsyncEspOTA myUpdater;    // connects to wifi on boot


#ifdef ARDUINO_ARCH_ESP32
#include "esp32-hal-log.h"		// convert esp-idf ESP_LOGx macros to Arduino's log_x macros
#endif

/*Found how to use eclipse with spiffs.

You have to add the following two lines to the debug configuration, Startup

mon program_esp ${workspace_loc:Spiffs/build/partition_table/partition-table.bin} 0x8000 verify
mon program_esp ${workspace_loc:Spiffs/build/storage.bin} 0x110000 verify

Where Spiffs is your project name and storage.bin is the binary file created by the following line added to your CMakeLists.txt

spiffs_create_partition_image(storage ../spiffs_image FLASH_IN_PROJECT)

partition-table.bin is created from your partitions_example.csv provided you have changed the sdkconfig to use a custom partition table.
*/


// ********************************************************************************
// menuconfig -> component config -> FreeRTOS -> Tick rate (hz) = 1000
// ********************************************************************************


//uncomment the following line to enable debug mode
#define __debug

// TODO: create method to change default APpassword and all it to be 
// reset back to factory default if user-created password is forgotten
// Hold a button during bootup??
// create/ Erase preference for APpassword


//forward declarations
void eraseAllPrefs();




/*
 *   Root index
 */

const char indexPageA[] PROGMEM = R"=====(
  <style>
  body {
    text-align: center;
    font-family: helvetica;
    background-color: steelblue;
    margin: 0;
  }
  </style> 
  <table width='90%' align='center'>
      <tr>
          <td colspan=3>
              <center><font size=5><b>
                  [Insert Product name here]
              </b></font></center>
          </td>
      </tr>
      <tr>
         <td colspan=3>Infrastructure IP Address =
              <A href="http://)=====";

const char indexPageB[] PROGMEM = R"=====(<br/>
           </td>
      </tr>
      <tr height='70'>
           <td>
                webpage served from AsyncESPOTA library
                <a href=/firmware/><button>Update Firmware</button></a>
           </td>
           <td>
                webpage served from AsyncESPOTA library
                <a href=/wifiSettings><button>WiFi Settings</button></a>
           </td>
            <td>
                <!-- a href=/settings><button></button></a -->
           </td>
      </tr>
      <tr height='70'>
           <td>
                webpage served from AsyncESPOTA library
                <a href=/crash><button>Crash Firmware</button></a>
           </td>
            <td>
                webpage served from AsyncESPOTA library
                <a href=/downloadcoredump><button>View total Counters</button></a>
           </td>
      </tr>
      <tr height='70'>
           <td>
                <a href=/logs><button>Download log data</button></a>
           </td>
           <td>
              <a href=/coolthingpage><button>do a cool thing</button></a>
           </td>
      </tr>
      
      <br>
      <br>
    </table>)=====";


String root(){
 String result = indexPageA
               + WiFi.localIP().toString()
               + "\">"
               + WiFi.localIP().toString()
               + "</a><p>"
               + "or use this url <A href=\""
               + "http://"
               + WiFi.softAPSSID()
               + ".local\">"
               + WiFi.softAPSSID()
               + ".local</a>"
               + " except on Android version <12."
               + indexPageB;
  return result;
}


//const char* saved[] PROGMEM = R"=====(
const char* saved =
  "<script>"
    "window.alert('Settings Saved');"
  "</script>";



// Show the home page page
void onRootIndexRequest(H4AW_HTTPHandler *handler){
  const char* rootIndex =  root().c_str();
  handler->send(200, "text/html", strlen(rootIndex), rootIndex);
}



/*
// Callback: receiving any WebSocket message
void onWebSocketEvent(uint8_t clientNum, WStype_t type, uint8_t * payload, size_t length) {
  Serial.println("A web socket event has been received");

  // Figure out the type of WebSocket event
  switch(type) {

    // Client has disconnected
    case WStype_DISCONNECTED:
      Serial.printf("[%u] Disconnected!\n", clientNum);
// ****************************************************************************************************************************
      myUpdater.setCurrentClient(clientNum, DISCONNECTED);
// ****************************************************************************************************************************
      break;

    // New client has connected
    case WStype_CONNECTED:
      Serial.println("[skewtch::onWebSocketEvent]connection request received");
      {
        IPAddress clientIP = webSocket.remoteIP(clientNum);
        Serial.printf("[%u] Connection from ", clientNum);
        Serial.println(clientIP.toString());
      }
      break;

    // Handle text messages from client
    case WStype_TEXT:
      // Print out raw message
      Serial.printf("[%u] Received text: %s\n", clientNum, payload);
      Serial.print("comparing string to test statement = ");
      Serial.println(strcmp((char *)payload, "?FirmwareProgress"));
// ****************************************************************************************************************************
      // Start sending progress bar info
      if(strcmp((char *)payload, "?FirmwareProgress") == 0 ) {
          webSocket.sendTXT(clientNum, "FirmwareProgress");      //just for debugging web client.. doesn't *do* anything

          // let myUpdater know which client requested a firmware update
          myUpdater.setCurrentClient(clientNum, PROGRESSSOCKET);
      }
// ****************************************************************************************************************************

      else if(strcmp((char *)payload, "?SketchQuery1") == 0 )
      {
          // webSocket.sendTXT(clientNum, "query1");
          //Do Stuff 1
      }
      else if(strcmp((char *)payload, "?SketchQuery2") == 0 )
      {
          // webSocket.sendTXT(clientNum, "query2");
          // Do stuff 2

      }else{  // Message not recognized.. write more code!! ;)
        Serial.printf("[%u] Message not recognized %S\n" ,clientNum, payload);
      }
      break;

    // For everything else: do nothing
    case WStype_BIN:
    case WStype_ERROR:
    case WStype_FRAGMENT_TEXT_START:
    case WStype_FRAGMENT_BIN_START:
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
    default:
      break;
  }
}
*/


void configureWebServer(){
    Serial.println("Starting web server");
/*
 * H4 has a built in notFound handler - no need to add another
 * H4 has a built in static file server that refers to SPIFFS - no need to add a nother
 */

    webServer.on("/", HTTP_GET, onRootIndexRequest);
/* TODO:  write giveMeAfunctionName() function or go lambda if you wish
 *  webServer.on("/settings", HTTP_GET, onSettingsIndexRequest);    //GET  !!
    webServer.on("/settings", HTTP_POST, onSettingsPost);           //POST !!
    webServer.on("/sync", HTTP_GET, giveMeAfunctionName);
    webServer.on("/diagnostics", HTTP_GET, giveMeAfunctionName);
    webServer.on("/totals", HTTP_GET, giveMeAfunctionName);
    webServer.on("/logs", HTTP_GET, giveMeAfunctionName);
    webServer.on("/coolthingpage", HTTP_GET, giveMeAfunctionName);
*/
}







void h4setup(){

    HAL_FS.begin(); // ESP32 cannot call this from constructor, so... mimic H4Plugins :) 
    
    Serial.begin(115200);
    while(!Serial);
    
    //eraseAllPrefs();

    AsyncEspOTA.begin();
    configureWebServer();   //Start the web server so they can set the SSIDs and Passwords via AP
    webServer.begin();
    
    //webSocket.begin();
    //webSocket.onEvent(onWebSocketEvent); 
    Serial.println("Web server is now completely alive - even if only on the AP interface");
}


void eraseAllPrefs(){
#ifdef __debug
  Serial.println("About to erase all prefs and restart uMC");
#endif  
  nvs_flash_erase();  //erase the NVS partition and  
  nvs_flash_init();   //initialise the NVE partition
  ESP.restart();
}
