#pragma once

#ifndef __AsyncEspOTA_H__
#define __AsyncEspOTA_H__

#include <Arduino.h>
// #include <esp_core_dump.h>		// initialise the core dump feature to dump crash data into nvs on crash
								// then upload coreDumpData to web server to analyse
	
	// C:\Users\LindsayM\AppData\Local\Arduino15\packages\esp32\hardware\esp32\2.0.7\tools\sdk\esp32\include\espcoredump\include
	// menuconfig - set coredump destination
	//			  -  set Panic handler behaviour	Print Registers and halt
	
	//  https://www.youtube.com/watch?v=MpD_3oVJAEs		
	
	// https://github.com/MathieuDeprez/ESP32_CoreDump_Arduino_1.0.6 - Platfoprm IO!!
	// https://github.com/sabado/esp32-easy-menuconfig/blob/main/patch/enable.menuconfig.patch 
	// https://medium.com/@bhautik.markeye/esp-idf-core-dump-on-the-uart-store-to-flash-and-send-to-a-server-f84064d1af6f
	
	
	/** 
	*	https://docs.espressif.com/projects/arduino-esp32/en/latest/lib_builder.html
	*
	*	https://espressif-docs.readthedocs-hosted.com/projects/arduino-esp32/en/latest/esp-idf_component.html  
	*
	*/
	
	
	
#include <functional>

#include <Preferences.h>        // Store an unknown # of SSID & password pairs
#define RW_MODE false
#define RO_MODE true

#include <WiFi.h>				// it's IoT... why not
#include <esp_wifi.h>			// needed to change WiFi protocol_bitmap
#include <esp_wps.h>			// to get at the WPS functions
	// C:\Users\LindsayM\AppData\Local\Arduino15\packages\esp32\hardware\esp32\2.0.7\tools\sdk\esp32\include\esp_wifi\include

#include <WiFiMulti.h>			// Connect to any saved SSID in Preferences and within radio range
#include "wifiSettings.h"		// http://[insert host]/wifiSettings html page:
								// Read preferences, 
								// scan for local WiFi networks every 15 seconds, 
								// TODO: connect via WPS, 
								// save SSID/Password credentials to Preferences NVS RAM

#include <SPIFFS.h>
#define FORMAT_SPIFFS_IF_FAILED false;	// let's not be erasing everything if we fail to read on first attempt...

#include <H4AsyncWebServer.h>	// Allow asynchronous web communications 
// #include <WebSocketsServer.h>	// Allow progress bar & restarting feedback during OTA updates

#include "index.h"				// http://[insert host]/Firmware.html page
								// developer can choose to permit any or all of 3 datasources:
									// Pre-programmed internet locations
									// user selectable (inter)network locations
									// Browser's local file system
								// Populate page with OTA capable Apps
								// Get available versions for each app
								// start OTA update
								// provide prwifiMultiogress feedback and return browser to home page when OTA complete.
								
#include <HTTPUpdate.h>			// Perform the OTA update
#include <Update.h>				// Gain access to the OTA progressCallbackFunction

#include <ESPmDNS.h>            // bonjour compliant mulitcastDNS for iOS, MacOS, Linux, Windows & Androids 12 and later

#ifndef HTTP_UPLOAD_BUFLEN
#define HTTP_UPLOAD_BUFLEN 1436
#endif

enum  socketDataType {
	PROGRESSSOCKET,
	DISCONNECTED
};

extern const char *ssidPrefix;
extern const char *APpassword;
		
extern H4AsyncWebServer webServer;
// extern WebSocketsServer webSocket;	// convert to H4 webSockets
extern const int wsPort;			// convert to AsyncWebServer's built in webSockets		// Do we need this for H4 ???

extern const char *appsURL;			// where to search on the network.internet for json file
extern bool allowAppsURL;			// Allow preconfigured OTA update path  ??
extern bool allowCustomPaths;		// Allow user to enter netwok/internet url for OTA update path  ??
extern bool allowLocal;				// Allow browser local file system OTA update path  ??

//chatGPT recommendation  I think it will generate duplicate definition
typedef std::function<void(size_t, size_t)> THandlerFunction_Progress;

					// inherit UpdateClass and httpUpdate		: private UpdateClass, private HTTPUpdate
class AsyncEspOTA_ {
	public:
		AsyncEspOTA_(const AsyncEspOTA_ &) = delete; // no copying
		AsyncEspOTA_ &operator=(const AsyncEspOTA_ &) = delete;
		static AsyncEspOTA_ &getInstance(); // Accessor for singleton instance
		
		void begin();
		void loop();	
		void end();
		
// all the webSockets stuff
		void setCurrentClient(uint8_t client_num, socketDataType type);
		
// all the OTAUpdate stuff
		// http paths to be used by the main loop
		String repoPath;
		String spiffPath;
		String binPath;
		
	private:	
		AsyncEspOTA_() = default; // Make constructor private
		
		long int savedTime;
		THandlerFunction_Progress progressCallback;		
		
		// a function to provide a Callback function to the Update library to get progress values.
		void setProgressCallback(THandlerFunction_Progress callback);
		
		// Calback function supplied to update superclass so we can send progress data to our webpage via a webSocketsServer
		void updateProgress(size_t progress, size_t total);
		
// all the Preferences stuff
		Preferences preferences;
		int maxCredentials=30;			// Delete and switch to chatGPT connectToWiFi function
		int savedCredentials=0;			// Change to numCredentials and chatPGPT
		
		typedef struct{
			const char *nameSpace;		// Delete and switch to chatGPT connectToWiFi function
			int wlanID;					// Delete and switch to chatGPT connectToWiFi function
			String ssid;
			String password;
		}Credentials;
		Credentials currentCredentials;
				
		void saveWifiCredentials(String& ssid, String& password);
		void deleteWifiCredentials(int index);
		
		bool tryCredentials();							// replace
		bool readCredentials (Credentials *readCred);	// replace	or modify ??
		bool saveCredentials (Credentials *saveCred);	// replace
		String readPref(String nameSpace, String key);	// replace
		
// all the WiFi configuration stuff
		WiFiMulti wifiMulti;
		WiFiClientSecure WiFiclient;
		String ssid;
		String password;
		uint32_t chipID;        // unique chip ID / serialNumber
		const char *APssid;		// set to: ssidPrefix_chipID at runtime

		void startAP();
		
		const char *wl_status_to_string(wl_status_t status);
		static void onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info);
		void connectToWiFi();
		
// WPS specific stuff							
// TODO:  Connect via WPS ???   insecure ??

// wps_type_t	predifined const values
//				WPS_TYPE_PBC	Push Button
//				WPS_TYPE_PIN	Pin

wps_type_t	wps_mode;
#define ESP_MANUFACTURER  "Red Pill software"
#define ESP_MODEL_NUMBER  "ESPAsyncEspOTA"
#define ESP_MODEL_NAME    "test"
#define ESP_DEVICE_NAME   "esp32 STATION"

		static esp_wps_config_t config;
		void wpsInitConfig();
		static String wpspin2string(uint8_t a[]);		
		void startWPS();
		void wpsStop();

// all the web server stuff
// WiFi settings page specific stuff		
		void onWiFiIndexRequest(H4AW_HTTPHandler *handler);		// serve up web page with saved settings
		void onWiFiSavedRequest(H4AW_HTTPHandler *handler);		// serve up the saved settings from Preferences
		void onWiFiScanRequest(H4AW_HTTPHandler *handler);		// serve up WIFI.Scan data

		void onWiFiSavePost(H4AW_HTTPHandler *handler);			// save Wireless LAN settings to preferences
		void onWiFiDeletePost(H4AW_HTTPHandler *handler);		// delete  Saved WiFi credentials
		
		
// Firmware update page specific stuff
		
		// Note: The following part is all about acting as a proxy. 
		// The esp32 will retrieve information on our behalf and then the front side will check periodically if we have something new

		// These are flags to notify the main loop to download information
		#define StateError      -1  	// Error while trying to retrieve information
		#define StateNoData      0  	// no data
		#define StateDataUpdated 1  	// data updated
		#define StateNeedUpdate  2  	// need update (this will trigger an http request in the main loop)
        #define StateWaitingSocket 3	// Waiting for WebSocketsServer connection to permit progress data to be sent to client

		// Responses saved in the main loop and checked by the webServer periodically
		String repoList;
		String repoInformation;			

		int repoListState 			= StateNoData;
		int repoInformationState 	= StateNoData;
		int repoInstallationState 	= StateNoData;
		
		void handleFirmware(H4AW_HTTPHandler *handler);		// serve up the htnl page to

		void handleRepoList(H4AW_HTTPHandler *handler);		// Fetch all project repo available
		void getRepoList();											// find which apps we can install
		void checkRepoList(H4AW_HTTPHandler *handler);


		void handleRepoInformation(H4AW_HTTPHandler *handler);
		void checkRepoInformation(H4AW_HTTPHandler *handler);
		void getRepoInformation();									// get the availavable version for a specifi app

		
		
		void handleUpload(H4AW_HTTPHandler *handler);
		
		void handleInstallFromRepo(H4AW_HTTPHandler *handler);
		void install(H4AW_HTTPHandler *handler);
		void installFromRepo(void);
		
		//flag to use from web update to reboot the ESP
		bool shouldReboot = false;
		void handleRestart(H4AW_HTTPHandler *handler);

		void onUpdateSPIFFS(H4AW_HTTPHandler *handler);	// get the images
		
// a helper function for diagnostics
		void printRequestDetails(H4AW_HTTPHandler *handler);
		
				
// all the webSockets tracking stuff
		String messagePrefix;	// s = SPIFFS, b = Binary Firmawre file
		String message;	
		uint8_t clientNum;
		
		bool SocketStarted = false;
		socketDataType socketData;
};
extern AsyncEspOTA_ &AsyncEspOTA;
#endif