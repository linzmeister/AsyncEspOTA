#include <H4AsyncEspOTA.h>

IPAddress localIP(192,168,4,1);			// for AP!!
IPAddress gatewayIP;					// set to STA's DHCP server gateway after connecting to STA
IPAddress subnetIP(255,255,255,0);
String Temp;

const char *wl_status_to_string(wl_status_t status){
  switch (status) {
    case WL_NO_SHIELD:
      return "WL_NO_SHIELD";
    case WL_IDLE_STATUS:
      return "WL_IDLE_STATUS";
    case WL_NO_SSID_AVAIL:
      return "WL_NO_SSID_AVAIL";
    case WL_SCAN_COMPLETED:
      return "WL_SCAN_COMPLETED";
    case WL_CONNECTED:
      return "WL_CONNECTED";
    case WL_CONNECT_FAILED:
      return "WL_CONNECT_FAILED";
    case WL_CONNECTION_LOST:
      return "WL_CONNECTION_LOST";
    case WL_DISCONNECTED:
      return "WL_DISCONNECTED";
    default:
      return "UNKNOWN";
  }
}



void AsyncEspOTA_::updateProgress(size_t progress,  size_t total){
	double progPercent = (float(progress)/float(total)*100);
	message = messagePrefix
	+ String(progress) 
	+ "," 
	+ String(total) 			//example message:   b999424,1012528#84.20%
	+ "#" 
	+ String(progPercent) 
	+ "%";
	
	//webSocket.sendTXT(clientNum, message);

	//	send a websocket message to reload the '/' page or force a back button press ??	
	if(messagePrefix =="b" && progPercent==100.00){
		//webSocket.sendTXT(clientNum,"Restarting");
	}
}


void AsyncEspOTA_::setProgressCallback(THandlerFunction_Progress callback) {
  this->progressCallback = callback;
}


void AsyncEspOTA_::onWiFiEvent(WiFiEvent_t event, WiFiEventInfo_t info){
	switch (event) { 
		case SYSTEM_EVENT_STA_CONNECTED:
			log_d("[WiFi_Event] Connected to WiFi Network %S", String(WiFi.SSID()));
			break;
      
		case SYSTEM_EVENT_STA_DISCONNECTED:
			log_i("[WiFi_Event] Disconnected from WiFi Network");
			break;

		case SYSTEM_EVENT_AP_START:
			log_d("[WiFi_Event] IP Address of Access Point: %s", WiFi.softAPIP());
			break;
		
		case SYSTEM_EVENT_AP_STOP:
			log_d("[WiFi_Event] WiFi access point stopped");
			break;

		case SYSTEM_EVENT_STA_STOP:
			log_d("[WiFi_Event] WiFi client stopped - no more internet access");
			break;
		
		case IP_EVENT_STA_GOT_IP :
			log_d("[WiFi_Event] Got IP: %S", WiFi.localIP().toString());
			MDNS.end();
			
			// Set softAPConfig gateway to Station gateway
			//gatewayIP = WiFi.gatewayIP();
			//WiFi.softAPConfig(localIP, gatewayIP, subnetIP);
//			 WiFi.softAPConfig(WiFi.localIP(), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
			/*
			tcpip_adapter_ip_info_t info = {0};
			tcpip_adapter_dns_info_t dns_info = {0};
			memset (&dns_info, 8, sizeof(dns_info));
			IP4_ADDR(&info.ip, 192, 168, 4, 1);
			IP4_ADDR(&info.gw, 0, 0, 0, 0);
			IP4_ADDR(&info.netmask, 255, 255, 255, 0);
			IP_ADDR4(&dns_info.ip, 4, 4, 4, 4);
			
			tcpip_adapter_dhcps_stop(TCPIP_ADAPTER_IF_AP);
			tcpip_adapter_set_ip_info(TCPIP_ADAPTER_IF_AP, &info);
			ESP_ERROR_CHECK(tcpip_adapter_set_dns_info(TCPIP_ADAPTER_IF_AP, TCPIP_ADAPTER_DNS_MAIN, &dns_info));
			dhcps_offer_t opt_val = OFFER_DNS; // supply a dns server via dhcps
			tcpip_adapter_dhcps_option(TCPIP_ADAPTER_OP_SET, TCPIP_ADAPTER_DOMAIN_NAME_SERVER, &opt_val, 1);
			tcpip_adapter_dhcps_start(TCPIP_ADAPTER_IF_AP);
			*
			
			/*bool softAPConfig(
			IPAddress local_ip, 
			IPAddress gateway, 
			IPAddress subnet, 
			IPAddress dhcp_lease_start = (uint32_t) 0);
			*/
				
			log_d("gateway should now be set to : %S", gatewayIP.toString());

			//use mdns for host name resolution
			if (MDNS.begin(WiFi.softAPSSID().c_str())) {
				log_d("[WiFi_Event] You can now connect to http:// %S.local", WiFi.softAPSSID());     //http://AsyncEspOTAxxxxx.local/
			} else {
				log_d("[WiFi_Event] Error setting up MDNS responder!");
			}
			
			WiFi.printDiag(Serial);
			break;	
		
		case WIFI_EVENT_STA_WPS_ER_SUCCESS :
                log_d("[WiFi_Event] WPS success.");
                break;
				
		case SYSTEM_EVENT_STA_WPS_ER_TIMEOUT:
                log_d("[WiFi_Event] WPS timeout.");
                break;
				
		case SYSTEM_EVENT_STA_WPS_ER_FAILED:
                log_d("[WiFi_Event] WPS failed.");
                break;
		
		case SYSTEM_EVENT_STA_WPS_ER_PIN:{
			log_d("[WiFi_Event] WPS_PIN = %S", wpspin2string(info.wps_er_pin.pin_code));
			//publish pin code to web page
			}
			break;
			
		case SYSTEM_EVENT_STA_WPS_ER_PBC_OVERLAP:{
			log_d("[WiFi_Event] WPS_PBC = %S", wpspin2string(info.wps_er_pin.pin_code));
			}
			break;
			
		default: 
			log_e ("[WiFi_Event] event # %s occurred", event);
			break;
	}
}

/*	typedef void (*WiFiEventCb)(arduino_event_id_t event);
	wifi_event_id_t onEvent(WiFiEventCb     cbEvent, arduino_event_id_t event = ARDUINO_EVENT_MAX);
	void removeEvent(WiFiEventCb            cbEvent, arduino_event_id_t event = ARDUINO_EVENT_MAX);
	
	typedef std::function<void(arduino_event_id_t event, arduino_event_info_t info)> WiFiEventFuncCb;	
    wifi_event_id_t onEvent(WiFiEventFuncCb cbEvent, arduino_event_id_t event = ARDUINO_EVENT_MAX);
    void removeEvent(wifi_event_id_t id);
	
	typedef void (*WiFiEventSysCb)(arduino_event_t *event)
	wifi_event_id_t onEvent(WiFiEventSysCb  cbEvent, arduino_event_id_t event = ARDUINO_EVENT_MAX);
    void removeEvent(WiFiEventSysCb         cbEvent, arduino_event_id_t event = ARDUINO_EVENT_MAX);
*/

/*
void AsyncEspOTA_::OnWiFiEvent(WiFiEvent_t event, arduino_event_info_t info){
  switch (event) { 
		
		default:
			log_d("Unknown WiFi event: %S", event);
			break;
        }
  }
}
*/



void AsyncEspOTA_::begin(){
	/**
	* Initializes core dump module internal data.  Should be called at system startup.
	*/
	void esp_core_dump_init(void);	
	
	for(int i=0; i<17; i=i+8) {
	chipID |= ((ESP.getEfuseMac() >> (40 - i)) & 0xff) << i;
	}
	Temp = String(ssidPrefix) + String(chipID);
	APssid=(Temp.c_str());
	
	/** 
	*	typedef enum {
	*		WIFI_IF_STA = ESP_IF_WIFI_STA,
	*		WIFI_IF_AP  = ESP_IF_WIFI_AP,
	*	} wifi_interface_t;
	*

	/**
	* @brief     Get the current protocol bitmap of the specified interface
	*
	* @param     ifx  interface
	* @param[out] protocol_bitmap  store current WiFi protocol bitmap of interface ifx
	*
	* @return
	*    - ESP_OK: succeed
	*    - ESP_ERR_WIFI_NOT_INIT: WiFi is not initialized by esp_wifi_init
	*    - ESP_ERR_WIFI_IF: invalid interface
	*    - ESP_ERR_INVALID_ARG: invalid argument
	*    - others: refer to error codes in esp_err.h
	*/
	esp_err_t wifiError;
	uint8_t protocol_bitmap;
	wifiError = esp_wifi_get_protocol(WIFI_IF_STA, &protocol_bitmap);
	log_e("[Begin] protocol bitmap contains: %u", protocol_bitmap);
	
	/**
	* @brief     Set protocol type of specified interface
	*            The default protocol is (WIFI_PROTOCOL_11B|WIFI_PROTOCOL_11G|WIFI_PROTOCOL_11N)
	*
	* @attention Support 802.11b or 802.11bg or 802.11bgn or LR mode
	*
	* @param     ifx  interfaces
	* @param     protocol_bitmap  WiFi protocol bitmap
	*
	* @return
	*    - ESP_OK: succeed
	*    - ESP_ERR_WIFI_NOT_INIT: WiFi is not initialized by esp_wifi_init
	*    - ESP_ERR_WIFI_IF: invalid interface
	*    - others: refer to error codes in esp_err.h
	*/
	
	protocol_bitmap = WIFI_PROTOCOL_11B|WIFI_PROTOCOL_11G|WIFI_PROTOCOL_11N;
	wifiError = esp_wifi_set_protocol(WIFI_IF_STA, protocol_bitmap);
	log_e("[Begin] after esp_wifi_set_protocol esp_err returned : %u", wifiError);
	
	
	protocol_bitmap=0;	// just so that I know the data is coming from the uMC
	wifiError = esp_wifi_get_protocol(WIFI_IF_STA, &protocol_bitmap);
	log_e("[Begin] protocol bitmap contains: %u", protocol_bitmap);
	
	tryCredentials();		// read Preferences and add to WifiMulti to connect.
	
	startAP();
	//WiFi.onEvent(std::bind(&AsyncEspOTA_::onWiFiEvent, this, std::placeholders::_1));
	WiFi.onEvent(onWiFiEvent);
	//std::bind(&AsyncEspOTA_::onWiFiEvent, this, std::placeholders::_1, std::placeholders::_2)
	
	setProgressCallback(std::bind(&AsyncEspOTA_::updateProgress, this, std::placeholders::_1, std::placeholders::_2));
	
	log_d("Setting up web server responders");
	/*
		sequence of event handlers is important   !!
		Longest branch paths first
		specific >>> general
	*/	
/* ***********************************************************************************************************************	
  // Simple Firmware Update Form

  webServer.on("/update", HTTP_GET, [](H4AW_HTTPHandler *handler){
    handler->send(200, "text/html",
	"<form method='POST' action='/update' enctype='multipart/form-data'><input type='file' name='update'><input type='submit' value='Update'></form>");
  });

//Browser's local OTA file update function to use as is or modify ....
 
 webServer.on("/update", HTTP_POST, [](H4AW_HTTPHandler *handler){
    bool shouldReboot = !Update.hasError();
    AsyncWebServerResponse *response = handler->beginResponse(200, "text/plain", shouldReboot?"OK":"FAIL");
    response->addHeader("Connection", "close");
    handler->send(response);
  },[](H4AW_HTTPHandler *handler, String filename, size_t index, uint8_t *data, size_t len, bool final){
    if(!index){
      Update.onProgress(updateProgress);  //progressCallbackFunction  
      log_d("Update Start: %s\n", filename.c_str());
      if(!Update.begin()){
        Update.printError(Serial);
      }
    }
    if(!Update.hasError()){
      if(Update.write(data, len) != len){
        Update.printError(Serial);
      }
    }
    if(final){
      if(Update.end(true)){
        log_d("Update Success: %uB\n", index+len);
      } else {
        Update.printError(Serial);
      }
    }
  });
// ************************************************************************************************************************	
*/		

	// respond to the restart button from the client 
	webServer.on("/restart", HTTP_GET, [this](H4AW_HTTPHandler *handler){
		handleRestart(handler);               
     });
	 
	//  read preferences - serve list to client
	webServer.on("/wifiSettings/saved", HTTP_GET, [this](H4AW_HTTPHandler *handler) {
		onWiFiSavedRequest(handler);
	});
	
	//  - Scan WiFi, serve list to client
	webServer.on("/wifiSettings/scan", HTTP_GET, [this](H4AW_HTTPHandler *handler) {
		 onWiFiScanRequest(handler);
	});

	// Client sends a body data of nameSpace, ssid & paasswords to save
	// Save wifiSettings posted from the page to preferences nv flashram
    webServer.on("/wifiSettings/saveWlan", HTTP_POST, [this](H4AW_HTTPHandler *handler){
		onWiFiSavePost(handler);
	});
	
		// Client sends a body data of nameSpace, ssid & paasswords to save
	// Save wifiSettings posted from the page to preferences nv flashram
    webServer.on("/wifiSettings/deleteWlan", HTTP_POST, [this](H4AW_HTTPHandler *handler){
		onWiFiDeletePost(handler);
	});
	
	// serve the /wifiSettings.hmtl page to client 
	webServer.on("/wifiSettings", HTTP_GET, [this](H4AW_HTTPHandler *handler){
		onWiFiIndexRequest(handler);               
    });
	
	// get version from internet
    webServer.on("/firmware/repo/info/request", HTTP_POST, [this](H4AW_HTTPHandler *handler){
        handleRepoInformation(handler);
    });
    
	//send version to client
	webServer.on("/firmware/repo/info", HTTP_GET, [this](H4AW_HTTPHandler *handler){
        checkRepoInformation(handler);
    });
    
	// get repo list from internet	
	webServer.on("/firmware/repo/list/request", HTTP_GET, [this](H4AW_HTTPHandler *handler){
        handleRepoList(handler);
    });
	
	// send list to client
	webServer.on("/firmware/repo/list", HTTP_GET, [this](H4AW_HTTPHandler *handler){
        checkRepoList(handler);
    });
	 
	// client sends spiifs/ bin paths to us
	webServer.on("/firmware/repo/install/request", HTTP_POST, [this](H4AW_HTTPHandler *handler){
        handleInstallFromRepo(handler);
    });
	 
	// send the /firmware HTML page to client 
	webServer.on("/firmware", HTTP_GET, [this](H4AW_HTTPHandler *handler){
        handleFirmware(handler);               
     });

	webServer.on("/updateSPIFFS", HTTP_GET, [this](H4AW_HTTPHandler *handler){
        onUpdateSPIFFS(handler);               
     });
	 
	//WiFi.scanNetworks();	// to speed up the first web page results.
	
	//See discussion: https://github.com/RomeHein/ESPInstaller/issues/2
	WiFiclient.setInsecure();
	
	// webSocket.broadcastTXT("reboot complete");
}
/*
	server.on("/update",HTTP_POST,[this]() { handleUpload(); }, [this]() { install(); });
	
	(H4AW_HTTPHandler *handler)> ArRequestHandlerFunction;
	(H4AW_HTTPHandler *handler, const String& filename, size_t index, uint8_t *data, size_t len, bool final)> ArUploadHandlerFunction;
	(H4AW_HTTPHandler *handler, uint8_t *data, size_t len, size_t index, size_t total)> ArBodyHandlerFunction;
	
	AsyncCallbackWebHandler& on(const char* uri, ArRequestHandlerFunction onRequest);
	AsyncCallbackWebHandler& on(const char* uri, WebRequestMethodComposite method, ArRequestHandlerFunction onRequest);
	AsyncCallbackWebHandler& on(const char* uri, WebRequestMethodComposite method, ArRequestHandlerFunction onRequest, ArUploadHandlerFunction onUpload);
	AsyncCallbackWebHandler& on(const char* uri, WebRequestMethodComposite method, ArRequestHandlerFunction onRequest, ArUploadHandlerFunction onUpload, ArBodyHandlerFunction onBody);
	void onNotFound(ArRequestHandlerFunction fn);  //called when handler is not assigned
    void onFileUpload(ArUploadHandlerFunction fn); //handle file uploads
    void onRequestBody(ArBodyHandlerFunction fn); //handle posts with plain body content (JSON often transmitted this way as a request)
*/


void AsyncEspOTA_::end(){
}

/*
//  local OTA file upload and flash	-- read AsyncWebServer doc to deconstruct
void AsyncEspOTA_::install(H4AW_HTTPHandler *handler){
			  
	webServer.on("/update",HTTP_POST,[](H4AW_HTTPHandler *handler){shouldReboot = !Update.hasError();
    AsyncWebServerResponse *response = handler->beginResponse(200, "text/plain", shouldReboot?"OK":"FAIL");
    response->addHeader("Connection", "close");
    handler->send(response);},
	[] (install) (H4AW_HTTPHandler *handler, String filename, size_t index, uint8_t *data, size_t len, bool final){
    if(!index){
      Update.onProgress(updateProgress);  //progressCallbackFunction  
      log_d("Update Start: %s\n", filename.c_str());
      if(!Update.begin()){
        Update.printError(Serial);
      }
    }
    if(!Update.hasError()){
      if(Update.write(data, len) != len){
        Update.printError(Serial);
      }
    }
    if(final){
      if(Update.end(true)){
        log_d("Update Success: %uB\n", index+len);
      } else {
        Update.printError(Serial);
      }
    }
  });
}
*/


/**
	@param wps_type_t
		WPS_TYPE_PBC		Push Button
		WPS_TYPE_PIN		Pin
*/
void AsyncEspOTA_::wpsInitConfig(){
	//config.crypto_funcs = &g_wifi_default_wps_crypto_funcs;
	
	// TODO:  need to set wps_mode before calling this function
	
	config.wps_type = wps_mode;
	strcpy(config.factory_info.manufacturer, ESP_MANUFACTURER);
	strcpy(config.factory_info.model_number, ESP_MODEL_NUMBER);
	strcpy(config.factory_info.model_name, ESP_MODEL_NAME);
	strcpy(config.factory_info.device_name, ESP_DEVICE_NAME);
}


String AsyncEspOTA_::wpspin2string(uint8_t a[]){
	char wps_pin[9];
	for(int i=0; i<8; i++){
		wps_pin[i] = a[i];
	}
	wps_pin[8] = '\0';
	return (String)wps_pin;
}


void AsyncEspOTA_::startWPS(){
	
	
/*	WiFiEventId_t eventID = WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info){
        Serial.print("WiFi lost connection. Reason: ");
        Serial.println(info.wifi_sta_disconnected.reason);
    }, WiFiEvent_t::ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
*/
	WiFi.mode(WIFI_MODE_APSTA);
	log_d("Starting WPS");

	wpsInitConfig();
	esp_wifi_wps_enable(&config);
	esp_wifi_wps_start(0);
}


void AsyncEspOTA_::wpsStop(){
    if(esp_wifi_wps_disable()){
    	log_d("WPS Disable Failed");
    }
}


void  AsyncEspOTA_::startAP(){ 
	log_d("Starting (Access Point) with ssid : %s", APssid);
	// Remove the password parameter, if you want the AP (Access Point) to be open

	WiFi.mode(WIFI_MODE_APSTA);
	
	WiFi.persistent(false);
	//WiFi.setAutoReconnect(true);	// WiFi Multi should take care of this
	WiFi.setSleep(false);
  
	//  TODO:  Allow user to choose their own APpassword, 
	// but to also reset to factory default if they forget
	WiFi.softAP(APssid, APpassword);      
	WiFi.softAPConfig(localIP, gatewayIP, subnetIP);
}


/** Attempt to read existing preferences.
    Then attempt to start Wi-Fi client with any saved credentials
*/
bool AsyncEspOTA_::tryCredentials(){
	log_d("inside tryCredentials");
	bool resp = false;
		
	String temp;
	for (int i = 0; i < maxCredentials; i++) {
		temp = "wlan-" + String(i);
		log_v("trying to read preference : %S", temp);
		currentCredentials.nameSpace=temp.c_str();
			
		if(readCredentials(&currentCredentials)){
			log_v("ssid key exists");				
			if(currentCredentials.ssid != ""){
				log_d("adding %s to WiFi-Multi list", currentCredentials.ssid);
				wifiMulti.addAP(currentCredentials.ssid.c_str(), currentCredentials.password.c_str());
				savedCredentials++;
				log_v("savedCredentials = %i ", savedCredentials);
				resp=true;
			}
		} else {
			log_d("readCredentials returned false");
		}
    }
	
	WiFi.mode(WIFI_MODE_STA);
	
	int i=0;
	log_d("Starting wifiMulti");
	while(wifiMulti.run() != WL_CONNECTED) {
		log_d("WiFi multi checking for networks to connect to");
		//delay(6000);
		i++;
		if (i>3){
			log_d("[AsyncEspOTA_.begin] No saved networks found");
			break;	
		}
	}
    return resp;
}

/*
void AsyncEspOTA_::saveWifiCredentials(String& ssid, String& password) {
	preferences.begin("credentials", RW_MODE);
	int numCredentials = preferences.getInt("num_credentials", 0);
	bool found=false;
	int updateIndex =0;
	
	// validate that the new credentials aren't already saved
	for (int i = 0; i < numCredentials; i++) {
		if(ssid = preferences.getString("ssid_" + String(i))){
			found=true;
			updateIndex = i;
			break;
		}
	}
  
	if(found){
		preferences.putString("ssid_" + String(updateIndex), ssid);
		preferences.putString("password_" + String(updateIndex), password);
	} else {
		preferences.putString("ssid_" + String(numCredentials), ssid);
		preferences.putString("password_" + String(numCredentials), password);
		
		// Update the number of credentials
		preferences.putInt("num_credentials", numCredentials + 1);
	}
	preferences.end();
	connectToWiFi();
}


void AsyncEspOTA_::deleteWifiCredentials(int index) {
	preferences.begin("credentials", RW_MODE);
	int numCredentials = preferences.getInt("num_credentials", 0);

	// Check if the index is valid
	if (index >= 0 && index < numCredentials) {
		// Delete the credentials at the specified index
		preferences.remove("ssid_" + String(index));
		preferences.remove("password_" + String(index));

		// Shift the remaining credentials down to fill the gap
		for (int i = index; i < numCredentials - 1; i++) {
			String ssid = preferences.getString("ssid_" + String(i + 1));
			String password = preferences.getString("password_" + String(i + 1));
			preferences.putString("ssid_" + String(i), ssid);
			preferences.putString("password_" + String(i), password);
		}
		// delete the last one
		preferences.remove("ssid_" + String(numCredentials));
		preferences.remove("password_" + String(numCredentials));

		// Update the number of credentials
		preferences.putInt("num_credentials", numCredentials - 1);
	}
	preferences.end();
	connectToWiFi();
}


void AsyncEspOTA_::connectToWiFi(){
	preferences.begin("credentials", RO_MODE);
	//wifiMulti.APlist(); for each and remove
	

	// Load Wi-Fi configuration from preferences
	numCredentials = preferences.getInt("num_credentials", 0);
	for (int i = 0; i < numCredentials; i++) {
		String ssid = preferences.getString("ssid_" + String(i));
		String password = preferences.getString("password_" + String(i));
		wifiMulti.addAP(ssid.c_str(), password.c_str());
	}

	// Connect to Wi-Fi using WiFiMulti
	int retries = 0;
	while (wifiMulti.run() != WL_CONNECTED && retries < 5) {
		delay(1000);
		log_v("Connecting to WiFi...");
		retries++;
	}
	if (wifiMulti.run() == WL_CONNECTED) {
		log_v("Connected to WiFi");
	} else {
		log_w("Failed to connect to WiFi");
	}

	preferences.end();
}
*/

/**   Accepts a Credentials pointer
 *    Updates the pointed to Struct
 */
bool AsyncEspOTA_::readCredentials (Credentials *readCred){
	bool resp = false;
	if (preferences.begin(readCred->nameSpace, RO_MODE)){
		log_e("nameSpace readable");
		if(preferences.isKey("ssid")){
			readCred->wlanID = preferences.getInt("wlanID", -1);
			readCred->ssid = preferences.getString("ssid", "FF");
			readCred->password = preferences.getString("password", "FF");
			if(readCred->wlanID != -1 && 
			   readCred->ssid != "FF" && 
			   readCred->password != "FF"){
				log_d("valid credentials found !-1, !FF etc");
				preferences.end();
				 resp = true;
			}
		} else {
			log_e("no Credentials present");
		}
	}

/*	
	if (preferences.begin("credentials", RO_MODE)){
	// Load Wi-Fi configuration from preferences
	int numCredentials = preferences.getInt("num_credentials", 0);
	for (int i = 0; i < numCredentials; i++) {
		String ssid = preferences.getString("ssid_" + String(i));
		String password = preferences.getString("password_" + String(i));
		// add 'em to a list of some sort.
	}
*/
	preferences.end();
	return resp;
}


bool AsyncEspOTA_::saveCredentials(Credentials *saveCred){
	bool resp = false;
	if(saveCred->ssid != ""){
		preferences.begin(saveCred->nameSpace, RW_MODE);
		preferences.putInt("wlanID", saveCred->wlanID);
		preferences.putString("ssid", saveCred->ssid);
		preferences.putString("password", saveCred->password);
		resp=true;
	}
	preferences.end();
	log_e("saved ");
	return resp;
}


void AsyncEspOTA_::loop(){
	log_v("inside AsyncEspOTA_::loop()");	
	log_v("repoListState = %S", String(repoListState));

	if (!WiFi.isConnected()){
		if (millis()-savedTime>6000){	// don't scan too frequenetly..  minumum 5 seconds
			savedTime=millis();
			log_d("[loop] runnig wifiMulti to try and reconnect");
			wifiMulti.run();
		}
	}
	
	if(SocketStarted){			// wait for webSockets onnection before 
		switch(socketData){
			/*
			case SCANSOCKET:
				break;
			case SAVEDSOCKET:
				break;
			*/	
			case PROGRESSSOCKET:
				repoInstallationState = StateNeedUpdate;	// Loop will update on next run cycle
				SocketStarted=false;	// why did I do this ?????
				break;
			case DISCONNECTED:
				SocketStarted = false;
				break;
			default:
				break;
		}
	}
	
	if (repoListState == StateNeedUpdate){
		repoListState = StateNoData;
		getRepoList();
    }
    if (repoInformationState == StateNeedUpdate && !repoPath.isEmpty()){
		repoInformationState = StateNoData;
		getRepoInformation();
    }

    if (repoInstallationState == StateNeedUpdate){
		repoInstallationState = StateNoData;
		installFromRepo();
    }
}


// Serve up the wiFiSettings web page
void AsyncEspOTA_::onWiFiIndexRequest(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::handleWiFiRequest");
	log_v(printRequestDetails(handler));
	String completeWifiPage = styleCSS;
	completeWifiPage += wifiPageA;
	completeWifiPage += wsPort;
	completeWifiPage += wifiPageB;
	
	handler->sendstring("text/html", completeWifiPage.c_str());
}


void AsyncEspOTA_::onWiFiSavedRequest(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::onWifiSavedRequest");
	log_v(printRequestDetails(handler));

	
	savedCredentials=0;
	String json = "[";
        for (int i = 0; i < maxCredentials; ++i) {
			//open Preferences in Read Only mode (true)
			String temp = "wlan-" + String(i);
			currentCredentials.nameSpace=temp.c_str();
			log_e("trying to read preference : %S", temp);
			
			if(readCredentials(&currentCredentials)){
					if(json.length()>3) json += ",";	// only add a comma if not first... and last cant reach here
					json += "{";
					json += "\"ns\":\"" 	+ String(currentCredentials.nameSpace) + "\",";
					json += "\"id\":\"" + String(currentCredentials.wlanID) + "\",";
					json += "\"ssid\":\""   + currentCredentials.ssid + "\",";
					json += "\"pass\":\"" 	+ currentCredentials.password + "\",";
					
					if  (currentCredentials.ssid == WiFi.SSID()){ 	// is this the network we are connected to??
						json += "\"cnctd\":\"true\"";				// let the client know..
					} else {
						json += "\"cnctd\":\"false\"";				// also if not
					}
					json += "}";
				savedCredentials++;
				log_e("savedCredentials = %i ", savedCredentials);
			}
        }
    json += "]";
	if (json.length()>3){
		handler->sendstring("text/json", json.c_str());	
		log_d("%S",json);
	} else {
		handler->sendstring("text/json", "[]");
		log_d("no Saved settings to send, sending empty set to client");
	}
}


void AsyncEspOTA_::onWiFiScanRequest(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::handleWifiScan");
	log_v(printRequestDetails(handler));
	log_d("current wifi mode is %i", WiFi.getMode());

	int found;
	String json = "[";
	
	//First request will return 0 results unless you start scan from somewhere else (loop/setup)
	//Do not request more often than 3-5 seconds
	int n = WiFi.scanComplete();
	//log_d("scanComplete() = "  + String(n));
	
	if(n == WIFI_SCAN_FAILED){
		log_d("WiFi scan failed");
		WiFi.scanNetworks(true);
	} else if(n){
		for (int i = 0; i < n; ++i){
			found=json.indexOf(WiFi.SSID(i));
			if(found == -1){		//show no duplicates - different channels, 2.4 (/5 GHz ??) bands
				if(i) json += ",";
				json += "{";
				json += "\"rssi\":\"" + String(WiFi.RSSI(i)) +"\",";
				json += "\"enc\":\"";
				json += (WiFi.encryptionType(i) == WIFI_AUTH_OPEN)? "O\"," : "C\",";

				if  (WiFi.SSID(i)==WiFi.SSID()){ 	// is the the network we are connected to??
					json += "\"cnctd\":\"true\",";
				} else {
					json += "\"cnctd\":\"false\",";
				}

				json += "\"ssid\":\""+WiFi.SSID(i) +"\"";
				json += "}";
			}
		}
		WiFi.scanDelete();
		if(WiFi.scanComplete() == -2){
		  WiFi.scanNetworks(true);
		}
	  }
	  json += "]"; 
	  handler->sendstring("text/json", json.c_str());
	  json = String();
}


void AsyncEspOTA_::onWiFiSavePost(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::onWiFiSavePost");
	log_v(printRequestDetails(handler));

	// check if these are existing or new credentials and 
	// savedCredentials++ if new
	
	// read the body of the POST and save the data to NVS preference memory
	//H4T_NVP_MAP param = handler->params();
	//log_d("%s",param);
	

		Serial.printf("FORM from %s URL=%s\n",handler->client()->remoteIPstring().data(),handler->url().data());
		
		for(auto const& p:handler->params()) Serial.printf("Param %s=%s\n",p.first.data(),p.second.data());
		
		Serial.printf("BODY DATA\n");
		dumphex(handler->bodyData(),handler->bodySize());
		
		std::string cmd=handler->params()["cmd"];
		
		Serial.printf("Individual parameter cmd=%s\n",cmd.data());
		handler->sendOK();
		
 
  
  /*
	for(auto const& param:handler->params()) Serial.printf("Param %s=%s\n",param.first.data(),param.second.data());
    log_d("BODY DATA\n");
    dumphex(handler->bodyData(),handler->bodySize());

    currentCredentials.nameSpace = handler->params()["ns"].c_+str();
	log_d("%s", currentCredentials.nameSpace);
	
	currentCredentials.wlanID = atoi(handler->params()["wlanID"].c_+str());
	log_d("%i", currentCredentials.wlanID);

	currentCredentials.ssid = handler->params()["ssid"].c_+str();
	log_d("%s", currentCredentials.ssid);
	
	currentCredentials.password = handler->params()["password"];
	log_d("%s", currentCredentials.password);

	if (currentCredentials.wlanID-savedCredentials==1) savedCredentials++;	//new network being saved
		
	saveCredentials (&currentCredentials);

    handler->sendstring("text/html", "saved");   // show the "Saved" notification message
*/
	tryCredentials();		// load saved settings into WiFi Multi to connect to saved network

}


void AsyncEspOTA_::onWiFiDeletePost(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::onWiFiPostDelete");
	log_v(printRequestDetails(handler));

	
	//H4T_NVP_MAP param = handler->params();
		Serial.printf("FORM from %s URL=%s\n",handler->client()->remoteIPstring().data(),handler->url().data());
		
		for(auto const& p:handler->params()) Serial.printf("Param %s=%s\n",p.first.data(),p.second.data());
		
		Serial.printf("BODY DATA\n");
		dumphex(handler->bodyData(),handler->bodySize());
		
		std::string cmd=handler->params()["cmd"];
		
		Serial.printf("Individual parameter cmd=%s\n",cmd.data());
		handler->sendOK();
/*	
	currentCredentials.wlanID = atoi(handler->params()["wLan"]);	//int in the range of 0 - 29
	
	String name;
	log_d("savedCredentials %i", savedCredentials);
	
	int indexToDelete = atoi(param("ns")value().c_str());	//convert char to int

	for(int i = 0; i < savedCredentials+1; i++){
		name = "wlan-" + String(i);
		
		if (i == indexToDelete){
			preferences.begin(name.c_str(), RW_MODE);
			if(preferences.isKey("ssid")){
				preferences.clear();
				preferences.end();
			}
		} else if (i > indexToDelete){
			// shuffle currentCredentials to lower number:
				// read existing values into currentCredentials,
				// change the currentCredentials.nameSpace & ID
				// save into new nameSpace
				
				currentCredentials.nameSpace= name.c_str();
				readCredentials(&currentCredentials);
				name = "wlan-" + String(i-1);
				currentCredentials.nameSpace = name.c_str();
				currentCredentials.wlanID--;
				saveCredentials(&currentCredentials);
		}
	}
	
	name = "wlan-" + String(savedCredentials-1);
	
	preferences.begin(name.c_str(), RW_MODE);
	log_d("attempting to delete nameSpace  = %s... THE LAST ONE!!", name);
	preferences.clear();
	preferences.end();
	
	savedCredentials--;
	log_d("savedCredentials %i\n", savedCredentials-1);
	handler->sendstring("text/html", "deleted");   // show the "Deleted" notification message	
*/
}


void AsyncEspOTA_::handleFirmware(H4AW_HTTPHandler *handler){
	log_d("inside AsyncEspOTA_::handleFirmware");
	log_v(printRequestDetails(handler));
	
	String completeProgressPage = styleCSS;
	completeProgressPage += updatePage;
	
	if (allowAppsURL){
		completeProgressPage += updatePageApps;
	}
	if (allowCustomPaths){
		completeProgressPage += updatePageCustom;
	}
	
	if (allowLocal){
		completeProgressPage += updatePageLocal;
	}

	completeProgressPage += updatePageBlocker;
	completeProgressPage += wsPort;
	completeProgressPage += progressPageB;
		
	handler->sendstring("text/html", completeProgressPage.c_str());
}


void AsyncEspOTA_::handleRepoList(H4AW_HTTPHandler *handler){
    log_d("inside AsyncEspOTA_::handleRepoList");
	log_v(printRequestDetails(handler));
	
	repoListState = StateNeedUpdate;
	log_d("Set repoListState = StateNeedUpdate");
    handler->sendOK();
}


void AsyncEspOTA_::getRepoList(){
	log_d("inside AsyncEspOTA_::getRepoList()");

	HTTPClient http;

	log_d("[SERVER] Retrieving repo list from %s\n", appsURL);

  http.begin(WiFiclient, appsURL);
  int httpResponseCode = http.GET();
  if (httpResponseCode > StateNoData)  {
	repoList = http.getString();
	repoListState = StateDataUpdated;

	log_d("Set repoListState = %S", String(repoListState));
    log_d("[SERVER] repo list retrieved: \n%s\n",repoList.c_str());
  } else{

	log_d("[SERVER] Could not get repo list. Error %d: %s\n", httpResponseCode, http.errorToString(httpResponseCode).c_str());

	repoListState = StateError;
	log_d("Set repoListState = %S", String(repoListState));
  }
  http.end();
}


void AsyncEspOTA_::checkRepoList(H4AW_HTTPHandler *handler) {
    log_d("inside AsyncEspOTA_::checkRepoList");
	log_v(printRequestDetails(handler));

	if (repoListState == StateDataUpdated) {
		log_d("sending repoList to request client");
		log_d("%S", repoList);
        handler->sendstring("text/json", repoList.c_str());
    } else {
		log_d("sending repoListState # to request client");
        handler->sendstring("text/plain", String(repoListState).c_str());
    }
}


void AsyncEspOTA_::handleRepoInformation(H4AW_HTTPHandler *handler){
    log_d("inside AsyncEspOTA_::handleRepoInformation");
	log_v(printRequestDetails(handler));

/*	if (handler->hasArg("repo")) {
        repoPath = handler->arg("repo") + "versions.json";
        repoInformationState = StateNeedUpdate;
		log_d("Set repoInformationState = %i", repoInformationState);
        handler->sendOK();
        return;
    }
    handler->send(503, "text/plain", 18, "Parameters missing");
*/
}


void AsyncEspOTA_::checkRepoInformation(H4AW_HTTPHandler *handler) {
    log_d("inside AsyncEspOTA_::checkRepoInformation");
	log_v(printRequestDetails(handler));
	
	if (repoInformationState == StateDataUpdated) {
		log_d("sending repoListInformation to request client");
		log_d("%S", repoInformation);
        handler->sendstring("text/json", repoInformation.c_str());
    } else {
		log_d("sending repoListInformationState # to request client");
        handler->sendstring("text/plain", String(repoInformationState).c_str());
    }
}


void AsyncEspOTA_::handleUpload(H4AW_HTTPHandler *handler){
    log_d("inside AsyncEspOTA_::handleUpload");
	log_v(printRequestDetails(handler));

	handler->sendstring("text/plain", (Update.hasError()) ? "FAIL" : "OK");
    ESP.restart(); 
}


void AsyncEspOTA_::getRepoInformation(){
	log_d("inside AsyncEspOTA_::getRepoInformation()");

	HTTPClient http;

	log_d("[SERVER] Retrieving repo information from %s\n",repoPath.c_str());

	http.begin(WiFiclient,repoPath.c_str());
	int httpResponseCode = http.GET();
	if (httpResponseCode > StateNoData){
		repoInformation = http.getString();
		repoInformationState = StateDataUpdated;

		log_d("Set repoInformationState = %S", String(repoInformationState));
		log_d("[SERVER] repo info retrieved: %s\n",repoInformation.c_str());
		http.end();
	}
	else
	{
		log_d("[SERVER] Could not get repo information: %s\n", http.errorToString(httpResponseCode).c_str());
		repoInformationState = StateError;
		log_d("Set repoInformationState = %S", String(repoInformationState));
		http.end();
	}
}


void AsyncEspOTA_::handleRestart(H4AW_HTTPHandler *handler) {
    log_d("inside AsyncEspOTA_::handleRestart");
	log_v(printRequestDetails(handler));

	handler->sendOK();
    ESP.restart();
}


void AsyncEspOTA_::handleInstallFromRepo(H4AW_HTTPHandler *handler) {
    log_d("inside AsyncEspOTA_::handleInstallFromRepo");
	log_v(printRequestDetails(handler));
/*	
	if (handler->hasArg("spiffsPath")) {
        spiffPath = handler->arg("spiffsPath");
        repoInstallationState = StateNeedUpdate;
		log_d("Set repoInstallationState = %S", String(repoInstallationState));
    }
    if (handler->hasArg("binPath")) {
        binPath = handler->arg("binPath");
		repoInstallationState = StateNeedUpdate;
		log_d("Set repoInstallationState = %S", String(repoInstallationState));
    }
	handler->sendOK();
*/
}


void AsyncEspOTA_::installFromRepo(void){
	log_d("inside AsyncEspOTA_::installFromRepo(void)");	

  if (!spiffPath.isEmpty()){		
    log_d("[OTA] start SPIFFS download from: %s\n",spiffPath.c_str());

	
	// initialise message with 's' for SPIFFS 
	messagePrefix = "s";

    t_httpUpdate_return spiffRet = httpUpdate.updateSpiffs(WiFiclient,spiffPath);
    switch (spiffRet)
    {
    case HTTP_UPDATE_FAILED:
		log_d("[OTA] Error (%d): %s\n", httpUpdate.getLastError(), httpUpdate.getLastErrorString().c_str());
//		webSocket.sendTXT(clientNum,"Upload incomplete");
      return;

    case HTTP_UPDATE_NO_UPDATES:
      log_d("[OTA] no updates");
//		webSocket.sendTXT(clientNum,"No Updates available");
      return;

    case HTTP_UPDATE_OK:
      log_d("[OTA] SPIFFS updated");
      break;
    }
  }

  if (!binPath.isEmpty()){
    log_d("[OTA] start BIN download from: %s\n",binPath.c_str());

	// initialise message with 'b' for BIN 
	messagePrefix = "b";
	
    t_httpUpdate_return binRet = httpUpdate.update(WiFiclient, binPath);
    switch (binRet){
		case HTTP_UPDATE_FAILED:
			log_d("[OTA] Error (%d): %s\n", httpUpdate.getLastError(), httpUpdate.getLastErrorString().c_str());
			repoInstallationState = StateError;
			log_d("Set repoInstallationState = %S", String(repoInstallationState));
//			webSocket.sendTXT(clientNum,"Upload incomplete");
			break;

		case HTTP_UPDATE_NO_UPDATES:
			log_d("[OTA] no updates");
			repoInstallationState = StateError;
			log_d("Set repoInstallationState = %S", String(repoInstallationState));
//			webSocket.sendTXT(clientNum,"No Updates available");
			break;

		case HTTP_UPDATE_OK:
			log_d("[OTA] BIN updated");
			repoInstallationState = StateDataUpdated;
			log_d("Set repoInstallationState = %S", String(repoInstallationState));
			//	send a websocket message to notify client we have finished
//			webSocket.sendTXT(clientNum,"Restarting");
			ESP.restart();
			break;
		}
  }
}


//	SCANSOCKET
//	SAVEDSOCKET		??
//	PROGRESSSOCKET
//	DISCONNECTED
/*void AsyncEspOTA_::setCurrentClient(uint8_t client_Num, socketDataType type){
	log_d("[AsyncEspOTA_::setCurrentClient] WebSocket client $i connected", clientNum);

	clientNum = clientNum;
	SocketStarted=true;
	socketData=type;
}
*/
void AsyncEspOTA_::onUpdateSPIFFS(H4AW_HTTPHandler *handler){
    log_d("inside AsyncEspOTA_::handleInstallFromRepo");
	log_v(printRequestDetails(handler));

	// download images from GitHub to SPIFFS

	// or use install from REPO - spiffs update logic???
/*	
	https://github.com/linzmeister/AsyncEspOTA_/blob/main/images/SPIFFS/bar1.png
	https://github.com/linzmeister/AsyncEspOTA_/blob/main/images/SPIFFS/bar2.png
	https://github.com/linzmeister/AsyncEspOTA_/blob/main/images/SPIFFS/bar3.png
	https://github.com/linzmeister/AsyncEspOTA_/blob/main/images/SPIFFS/bar4.png
	https://github.com/linzmeister/AsyncEspOTA_/blob/main/images/SPIFFS/bar5.png
	https://github.com/linzmeister/AsyncEspOTA/blob/main/images/SPIFFS/open.png
	https://github.com/linzmeister/AsyncEspOTA/blob/main/images/SPIFFS/closed.png
*/

}

void AsyncEspOTA_::printRequestDetails(H4AW_HTTPHandler *handler){
	int i;
/*
	log_d("request details:");

	log_d("%ui", handler->version());      // uint8_t: 0 = HTTP/1.0, 1 = HTTP/1.1
	log_d("%i", handler->method());        // enum:    HTTP_GET, HTTP_POST, HTTP_DELETE, HTTP_PUT, HTTP_PATCH, HTTP_HEAD, HTTP_OPTIONS
	log_d("%S", handler->url());           // String:  URL of the request (not including host, port or GET parameters)
	log_d("%S", handler->host());          // String:  The requested host (can be used for virtual hosting)
	log_d("%S", handler->contentType());   // String:  ContentType of the request (not avaiable in Handler::canHandle)
	log_d("%i", handler->contentLength()); // size_t:  ContentLength of the request (not avaiable in Handler::canHandle)
	log_d("%b", handler->multipart());     // bool:    True if the request has content type "multipart"
	
	//List all collected headers
	int headers = handler->headers();
	  for(i=0;i<headers;i++){
	  AsyncWebHeader* h = handler->getHeader(i);
	  log_d("HEADER[%s]: %s\n", h->name().c_str(), h->value().c_str());
	}

	//List all collected headers (Compatibility)
	//int headers = handler->headers();
	//int i;
	for(i=0;i<headers;i++){
	  log_d("HEADER[%s]: %s\n", handler->headerName(i).c_str(), handler->header(i).c_str());
	}

	//get specific header by name (Compatibility)
	if(handler->hasHeader("MyHeader")){
	  log_d("MyHeader: %s\n", handler->header("MyHeader").c_str());
	}
	
		//Check if GET parameter exists
	if(handler->hasParam("download"))
	  H4T_NVP_MAP param = handler->params("download");

	//Check if POST (but not File) parameter exists
	if(handler->hasParam("download", true))
	  H4T_NVP_MAP param = handler->params("download", true);

	//Check if FILE was uploaded
	if(handler->hasParam("download", true, true))
	  H4T_NVP_MAP param = handler->params("download", true, true);

	//List all parameters
	int params = handler->params();
	for(i=0;i<params;i++){
	  H4T_NVP_MAP param = handler->params();
	  if(p->isFile()){ //p->isPost() is also true
		log_d("FILE[%s]: %s, size: %u\n", p->name().c_str(), p->value().c_str(), p->size());
	  } else if(p->isPost()){
		log_d("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
	  } else {
		log_d("GET[%s]: %s\n", p->name().c_str(), p->value().c_str());
	  }
	}
  
	//List all parameters (Compatibility)
	int args = handler->args();
	for(i=0;i<args;i++){
	  log_d("ARG[%s]: %s\n", handler->argName(i).c_str(), handler->arg(i).c_str());
	}
	*/
}


// default constructor
//AsyncEspOTA_::AsyncEspOTA_(){
//}

AsyncEspOTA_ &AsyncEspOTA_::getInstance() {	// access library arduino style
  static AsyncEspOTA_ instance;
  return instance;
}

AsyncEspOTA_ &AsyncEspOTA = AsyncEspOTA.getInstance();

/*
static esp_err_t download_get_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "application/octet-stream");
  httpd_resp_set_hdr(req, "Content-Disposition",
                     "attachment;filename=core.bin");

  esp_partition_iterator_t partition_iterator = esp_partition_find(
      ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_COREDUMP, "coredump");

  const esp_partition_t *partition = esp_partition_get(partition_iterator);

  int file_size = 65536;
  int chunk_size = 1024;
  int i = 0;
  for (i = 0; i < (file_size / chunk_size); i++) {
    char store_data[chunk_size];
    ESP_ERROR_CHECK(
        esp_partition_read(partition, i * chunk_size, store_data, chunk_size));
    httpd_resp_send_chunk(req, store_data, chunk_size);
  }
  uint16_t pending_size = file_size - (i * chunk_size);
  char pending_data[pending_size];
  if (pending_size > 0) {
    ESP_ERROR_CHECK(esp_partition_read(partition, i * chunk_size, pending_data,
                                       pending_size));
    httpd_resp_send_chunk(req, pending_data, pending_size);
  }
  httpd_resp_send_chunk(req, NULL, 0);
  return ESP_OK;
}


static const httpd_uri_t download = {
    .uri = "/download",
    .method = HTTP_GET,
    .handler = download_get_handler,
    .user_ctx = NULL,
};


static esp_err_t crash_get_handler(httpd_req_t *req) {
  const size_t index_size = (index_end - index_start);
  httpd_resp_set_type(req, "text/html");
  httpd_resp_send_chunk(req, (const char *)index_start, index_size);
  httpd_resp_send_chunk(req, NULL, 0);
  assert(0);
  return ESP_OK;
}


static const httpd_uri_t crash = {
    .uri = "/crash",
    .method = HTTP_GET,
    .handler = crash_get_handler,
    .user_ctx = NULL,
};
*/